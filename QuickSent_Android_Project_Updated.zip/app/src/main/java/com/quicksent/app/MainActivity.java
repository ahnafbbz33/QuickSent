package com.quicksent.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.wifi.p2p.*;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

public class MainActivity extends Activity {
    private WifiP2pManager manager;
    private WifiP2pManager.Channel channel;
    private BroadcastReceiver receiver;
    private IntentFilter filter;
    private TextView status, peersText;
    private Button discoverBtn, sendBtn;
    private final List<WifiP2pDevice> peers = new ArrayList<>();
    private WifiP2pDevice selected;
    private Uri selectedFile;
    private static final int PICK_FILE = 41;
    private static final int PORT = 8988;
    private boolean receiverStarted = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 9);
        }
        manager = (WifiP2pManager)getSystemService(WIFI_P2P_SERVICE);
        channel = manager.initialize(this, getMainLooper(), null);
        filter = new IntentFilter();
        filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        filter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        receiver = new P2pReceiver();
        discoverBtn.setOnClickListener(v -> discover());
        sendBtn.setOnClickListener(v -> pickFile());
        status.setText("প্রস্তুত। দুই ফোনেই QuickSent খুলুন এবং Wi-Fi চালু রাখুন।");
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(28, 35, 28, 24); page.setBackgroundColor(0xfff5f8fd);
        TextView title = new TextView(this); title.setText("➤  QuickSent"); title.setTextSize(27); title.setTextColor(0xff155fc4); title.setTypeface(null, 1);
        page.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("Offline Wi‑Fi Direct file sharing"); subtitle.setTextSize(14); subtitle.setTextColor(0xff64748b);
        page.addView(subtitle);
        status = new TextView(this); status.setTextSize(14); status.setTextColor(0xff243247); status.setPadding(0,28,0,18); page.addView(status);
        discoverBtn = new Button(this); discoverBtn.setText("কাছের ডিভাইস খুঁজুন"); page.addView(discoverBtn);
        peersText = new TextView(this); peersText.setText("কোনো ডিভাইস পাওয়া যায়নি"); peersText.setTextSize(14); peersText.setPadding(0,18,0,18); page.addView(peersText);
        sendBtn = new Button(this); sendBtn.setText("ফাইল নির্বাচন ও পাঠান"); sendBtn.setEnabled(false); page.addView(sendBtn);
        TextView hint = new TextView(this); hint.setText("\nব্যবহার:\n১) দুই ফোনেই QuickSent খুলুন।\n২) দুই ফোনে Wi‑Fi চালু করুন।\n৩) এক ফোনে ডিভাইস খুঁজুন, তালিকা থেকে অন্য ফোন নির্বাচন করুন।\n৪) সংযোগ হলে ফাইল নির্বাচন করে পাঠান।\n\nগ্রহণ করা ফাইল Downloads/QuickSent ফোল্ডারে সংরক্ষিত হবে।"); hint.setTextSize(13); hint.setTextColor(0xff526176); page.addView(hint);
        setContentView(page);
    }

    @Override protected void onResume() { super.onResume(); if(receiver!=null) registerReceiver(receiver, filter); }
    @Override protected void onPause() { super.onPause(); try { if(receiver!=null) unregisterReceiver(receiver); } catch(Exception ignored){} }
    private void discover() {
        if (manager == null) { status.setText("এই ফোনে Wi‑Fi Direct সমর্থিত নয়।"); return; }
        status.setText("ডিভাইস খোঁজা হচ্ছে…");
        manager.discoverPeers(channel, new WifiP2pManager.ActionListener() {
            public void onSuccess() { status.setText("খোঁজা শুরু হয়েছে। অন্য ফোনে QuickSent খুলে রাখুন।"); }
            public void onFailure(int r) { status.setText("ডিভাইস খোঁজা যায়নি। Wi‑Fi ও Location চালু করে আবার চেষ্টা করুন। কোড: "+r); }
        });
    }
    private void loadPeers() {
        manager.requestPeers(channel, list -> {
            peers.clear(); peers.addAll(list.getDeviceList());
            if(peers.isEmpty()){ peersText.setText("কোনো ডিভাইস পাওয়া যায়নি। আবার খুঁজুন।"); return; }
            String[] names = new String[peers.size()];
            for(int i=0;i<peers.size();i++) names[i]=(i+1)+". "+peers.get(i).deviceName+" ("+stateName(peers.get(i).status)+")";
            new AlertDialog.Builder(this).setTitle("ডিভাইস নির্বাচন করুন").setItems(names,(d,which)->connect(peers.get(which))).setNegativeButton("বন্ধ",null).show();
            StringBuilder sb=new StringBuilder("পাওয়া গেছে: "); for(WifiP2pDevice p:peers) sb.append(p.deviceName).append("  ");
            peersText.setText(sb.toString());
        });
    }
    private String stateName(int s){ switch(s){case WifiP2pDevice.AVAILABLE:return "Available";case WifiP2pDevice.CONNECTED:return "Connected";case WifiP2pDevice.INVITED:return "Invited";default:return "Busy";} }
    private void connect(WifiP2pDevice device) {
        selected=device; WifiP2pConfig config=new WifiP2pConfig(); config.deviceAddress=device.deviceAddress;
        status.setText(device.deviceName+"-এর সঙ্গে সংযোগ হচ্ছে…");
        manager.connect(channel,config,new WifiP2pManager.ActionListener(){
            public void onSuccess(){status.setText("সংযোগের অনুরোধ পাঠানো হয়েছে…");}
            public void onFailure(int r){status.setText("সংযোগ ব্যর্থ। আবার চেষ্টা করুন। কোড: "+r);}
        });
    }
    private void pickFile() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i,PICK_FILE);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK_FILE && result==RESULT_OK && data!=null){
            selectedFile=data.getData(); getContentResolver().takePersistableUriPermission(selectedFile,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            sendSelectedFile();
        }
    }
    private void sendSelectedFile(){
        if(selectedFile==null)return;
        status.setText("ফাইল পাঠানো হচ্ছে…");
        new Thread(()->{
            try{
                WifiP2pInfo[] infoHolder=new WifiP2pInfo[1];
                CountDownLatch latch=new CountDownLatch(1);
                manager.requestConnectionInfo(channel, info->{infoHolder[0]=info;latch.countDown();});
                if(!latch.await(10,java.util.concurrent.TimeUnit.SECONDS)||infoHolder[0]==null||!infoHolder[0].groupFormed)throw new Exception("ডিভাইস সংযুক্ত নয়");
                WifiP2pInfo info=infoHolder[0];
                Socket socket=new Socket(); socket.connect(new InetSocketAddress(info.groupOwnerAddress,PORT),15000);
                OutputStream out=new BufferedOutputStream(socket.getOutputStream());
                String name=getName(selectedFile); long size=getSize(selectedFile);
                DataOutputStream dataOut=new DataOutputStream(out); dataOut.writeUTF(name); dataOut.writeLong(size);
                InputStream in=getContentResolver().openInputStream(selectedFile); byte[] buf=new byte[64*1024]; int n;
                while((n=in.read(buf))!=-1)dataOut.write(buf,0,n);
                dataOut.flush(); in.close(); socket.close();
                runOnUiThread(()->status.setText("ফাইল পাঠানো সম্পন্ন: "+name));
            }catch(Exception e){runOnUiThread(()->status.setText("পাঠানো যায়নি: "+e.getMessage()));}
        }).start();
    }
    private String getName(Uri u){String n="QuickSent_file";try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)n=c.getString(x);}}catch(Exception ignored){}return n;}
    private long getSize(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int x=c.getColumnIndex(OpenableColumns.SIZE);if(x>=0)return c.getLong(x);}}catch(Exception ignored){}return -1;}
    private void startServer(){
        if(receiverStarted)return; receiverStarted=true;
        new Thread(()->{
            try(ServerSocket server=new ServerSocket(PORT)){
                while(true){Socket s=server.accept(); receiveOne(s);}
            }catch(Exception e){runOnUiThread(()->status.setText("রিসিভ সার্ভার সমস্যা: "+e.getMessage()));}
        }).start();
    }
    private void receiveOne(Socket socket){
        try{
            DataInputStream in=new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            String name=in.readUTF(); long size=in.readLong();
            if(Build.VERSION.SDK_INT>=29){
                android.content.ContentValues values=new android.content.ContentValues();
                values.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,name);
                values.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/octet-stream");
                values.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,"Download/QuickSent");
                Uri dest=getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                if(dest==null)throw new IOException("ফাইল তৈরি করা যায়নি");
                try(OutputStream out=getContentResolver().openOutputStream(dest)){copyExact(in,out,size);}
            }else{
                File dir=new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS),"QuickSent");dir.mkdirs();
                try(OutputStream out=new FileOutputStream(new File(dir,name))){copyExact(in,out,size);}
            }
            socket.close();runOnUiThread(()->status.setText("ফাইল গ্রহণ সম্পন্ন: "+name));
        }catch(Exception e){runOnUiThread(()->status.setText("ফাইল গ্রহণ ব্যর্থ: "+e.getMessage()));}
    }
    private void copyExact(InputStream in,OutputStream out,long size)throws IOException{
        byte[] b=new byte[64*1024]; if(size<0){int n;while((n=in.read(b))!=-1)out.write(b,0,n);}else{long left=size;while(left>0){int n=in.read(b,0,(int)Math.min(b.length,left));if(n<0)throw new EOFException();out.write(b,0,n);left-=n;}}out.flush();
    }
    private class P2pReceiver extends BroadcastReceiver{
        public void onReceive(Context c,Intent i){String a=i.getAction();
            if(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(a))loadPeers();
            else if(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(a)){
                if(Build.VERSION.SDK_INT>=23){android.net.NetworkInfo ni=i.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);if(ni!=null&&ni.isConnected()){
                    manager.requestConnectionInfo(channel,info->{if(info.groupFormed){runOnUiThread(()->{status.setText("সংযুক্ত! এখন ফাইল পাঠাতে পারবেন।");sendBtn.setEnabled(true);});if(info.isGroupOwner)startServer();else startServer();}});
                }else runOnUiThread(()->{status.setText("সংযোগ বিচ্ছিন্ন");sendBtn.setEnabled(false);});}
            }else if(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(a)){
                int state=i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE,-1);if(state==WifiP2pManager.WIFI_P2P_STATE_DISABLED)runOnUiThread(()->status.setText("Wi‑Fi বন্ধ আছে। চালু করুন।"));
            }
        }
    }
}
